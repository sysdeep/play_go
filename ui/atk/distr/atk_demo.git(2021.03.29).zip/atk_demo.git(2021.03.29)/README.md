# atk_demo

	go get github.com/visualfc/atk
	go get github.com/visualfc/atk_demo


### ATK
https://github.com/visualfc/atk

### ATK macOS deploy demo

https://github.com/visualfc/atk_demo/tree/master/calc

### tcl/tk for mingw64 download

https://github.com/visualfc/atk_mingw
