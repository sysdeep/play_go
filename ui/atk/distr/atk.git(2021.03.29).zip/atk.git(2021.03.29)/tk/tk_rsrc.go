// +build ignore

package tk

// go get github.com/akavel/rsrc

//go:generate rsrc -manifest tk.manifest -arch amd64
//go:generate rsrc -manifest tk.manifest -arch 386
